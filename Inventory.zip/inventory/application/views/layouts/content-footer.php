<footer class="main-footer">
	<div class="pull-right hidden-xs">
	  <b>Moderator:</b> Cedie Ian C. Lamela BSIT-4
	</div>
	<strong>Cebu Institute Technology-University N.Bacalso Ave,Cebu City 6000 &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp Phone:261-77-41 local 115 </strong>
</footer>